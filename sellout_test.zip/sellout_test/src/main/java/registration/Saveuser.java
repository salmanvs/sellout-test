package registration;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import registration.User;
import registration.UserDAO;

/**
 * Servlet implementation class Saveuser
 */
@WebServlet("/Saveuser")
public class Saveuser extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Saveuser() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		
		
		User e=new User();
		
		e.setEmail(email);
		e.setPassword(password);
		
		
		
		int status=UserDAO.save(e);
		if(status>0) {
			
			request.getRequestDispatcher("success.jsp").include(request, response);
		}else {
			out.print("sorry unable to save record");
		}out.close();
	}

}