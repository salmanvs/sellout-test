package profile_dummy;

public class DatabaseConnection {
	public static final String driverClass = "com.mysql.jdbc.Driver";
	public static final String connectionUrl = "jdbc:mysql://localhost:3306/sellout";
	public static final String username = "root";
	public static final String password = "";

}
