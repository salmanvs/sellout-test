package profile_dummy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


import profile_dummy.User_profileDAO;

public class User_profileDAO {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(DatabaseConnection.driverClass);
			con = DriverManager.getConnection(DatabaseConnection.connectionUrl,DatabaseConnection.username,DatabaseConnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;

	}

	 public static int save(User_profile e){  
	        int status=0;  
	        try{  
	            Connection con=User_profileDAO.getConnection();  
	            PreparedStatement ps=con.prepareStatement("insert into user_details(user_details_name,user_details_mobile_number,user_details_place,user_details_email,user_details_country,user_details_state) values (?,?,?,?,?,?)");  
	            ps.setString(1,e.getName());
	            ps.setInt(2,e.getMobile_number());
	            ps.setString(3,e.getPlace());
	            ps.setString(4,e.getEmail());
	            ps.setString(5,e.getCountry());
	            ps.setString(6,e.getState());  
  
	              
	              
	            status=ps.executeUpdate();  
	              
	            con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return status;  
	    }

}
