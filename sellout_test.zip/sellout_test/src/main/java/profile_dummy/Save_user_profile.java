package profile_dummy;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import profile_dummy.User_profile;
import profile_dummy.User_profileDAO;

/**
 * Servlet implementation class Save_user_profile
 */
@WebServlet("/Save_user_profile")
public class Save_user_profile extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Save_user_profile() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	/*
	 * protected void doGet(HttpServletRequest request, HttpServletResponse
	 * response) throws ServletException, IOException { // TODO Auto-generated
	 * method stub
	 * response.getWriter().append("Served at: ").append(request.getContextPath());
	 * }
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String name = request.getParameter("name");
		int mobile_number = Integer.parseInt(request.getParameter("mobile_number"));
		String place = request.getParameter("place");
		String email = request.getParameter("email");
		String country = request.getParameter("country");
		String state = request.getParameter("state");

		User_profile e = new User_profile();
		e.setName(name);
		e.setMobile_number(mobile_number);
		e.setPlace(place);
		e.setEmail(email);
		e.setCountry(country);
		e.setState(state);

		int status = User_profileDAO.save(e);
		if (status > 0) {
			request.getRequestDispatcher("success.jsp").include(request, response);
		} else {
			out.print("sorry unable to save record");
		}
		out.close();
	}
}
