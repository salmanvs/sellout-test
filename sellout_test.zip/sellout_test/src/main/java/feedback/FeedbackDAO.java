package feedback;

import java.sql.*;

public class FeedbackDAO {
	public static Connection getConnection() {

		Connection con = null;
		try {
			Class.forName(DatabaseConnection.DriverClass);
			con = DriverManager.getConnection(DatabaseConnection.ConnectionUrl,DatabaseConnection.username,DatabaseConnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
	
		return con;

}

public static int save(Feedback u) {
	int status = 0;
	try {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("insert into feedback(feedback_user_feedback) values(?)");
		ps.setString(1,u.getFeedback_user_feedback());
		
		status = ps.executeUpdate();
	} catch (Exception e) {
		System.out.println(e);
	}
	return status;
}

}
