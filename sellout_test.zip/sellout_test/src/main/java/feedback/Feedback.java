package feedback;

public class Feedback {
	
	private int id;
	private String feedback_user_feedback;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getFeedback_user_feedback() {
		return feedback_user_feedback;
	}
	public void setFeedback_user_feedback(String feedback_user_feedback) {
		this.feedback_user_feedback = feedback_user_feedback;
	}
	
	
	

}
