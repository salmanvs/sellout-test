package card_dummy;

public class Card {
	private int id;
	private String Card_holder_name, Bank_name, card_number, mobile_number;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCard_number() {
		return card_number;
	}

	public void setCard_number(String card_number) {
		this.card_number = card_number;
	}

	public String getMobile_number() {
		return mobile_number;
	}

	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}

	public String getCard_holder_name() {
		return Card_holder_name;
	}

	public void setCard_holder_name(String card_holder_name) {
		Card_holder_name = card_holder_name;
	}

	public String getBank_name() {
		return Bank_name;
	}

	public void setBank_name(String bank_name) {
		Bank_name = bank_name;
	}

}
