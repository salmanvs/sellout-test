package addStadium_dummy;

public class DatabaseConnection {
	public static final String DriverClass = "com.mysql.jdbc.Driver";
	public static final String ConnectionUrl = "jdbc:mysql://localhost:3306/sellout";
	public static final String username = "root";
	public static final String password = "";

}
